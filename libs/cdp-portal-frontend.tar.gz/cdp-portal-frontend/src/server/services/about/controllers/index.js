import { serviceController } from '~/src/server/services/about/controllers/service'
import { serviceListController } from '~/src/server/services/about/controllers/service-list'
import { serviceCreateStatusController } from '~/src/server/services/about/controllers/service-create-status'

export {
  serviceController,
  serviceListController,
  serviceCreateStatusController
}
