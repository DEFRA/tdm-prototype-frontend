const repositoryVisibility = ['public', 'internal', 'private']

export { repositoryVisibility }
