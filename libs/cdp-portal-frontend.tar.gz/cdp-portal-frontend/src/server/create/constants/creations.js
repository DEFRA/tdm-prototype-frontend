const creations = {
  microservice: 'microservice',
  repository: 'repository',
  'journey-test-suite': 'journey tests',
  'env-test-suite': 'environment test suite',
  'smoke-test-suite': 'smoke test suite',
  'perf-test-suite': 'performance test suite'
}

export { creations }
