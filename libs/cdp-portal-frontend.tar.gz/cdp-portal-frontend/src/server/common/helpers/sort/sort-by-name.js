const sortByName = (a, b) => a.localeCompare(b)

export { sortByName }
