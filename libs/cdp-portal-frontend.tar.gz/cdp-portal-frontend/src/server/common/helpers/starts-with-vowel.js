function startsWithVowel(string) {
  return !!string.match(/^[aeiou]/i)
}

export { startsWithVowel }
