import { deploymentController } from '~/src/server/deployments/controllers/deployment'
import { deploymentsListController } from '~/src/server/deployments/controllers/deployments-list'

export { deploymentController, deploymentsListController }
