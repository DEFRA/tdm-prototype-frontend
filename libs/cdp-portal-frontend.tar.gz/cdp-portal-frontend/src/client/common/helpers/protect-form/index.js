import { protectForm } from '~/src/client/common/helpers/protect-form/protect-form'

export { protectForm }
