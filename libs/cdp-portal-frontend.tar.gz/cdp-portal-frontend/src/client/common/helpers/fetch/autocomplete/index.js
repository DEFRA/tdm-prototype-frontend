import { fetchVersions } from '~/src/client/common/helpers/fetch/autocomplete/fetch-versions'

export { fetchVersions }
