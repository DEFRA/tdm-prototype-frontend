const eventName = {
  xhrUpdate: 'xhrUpdate',
  autocompleteUpdate: 'autocompleteUpdate'
}

export { eventName }
